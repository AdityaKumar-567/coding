import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthServiceService {
  signIn(credentials: {
    email: string;
    password: string;
  }): Observable<boolean> {
    console.log('Signing in:', credentials);
    return of(true); // Simulating API response
  }

  signUp(credentials: {
    email: string;
    password: string;
  }): Observable<boolean> {
    console.log('Signing up:', credentials);
    return of(true); // Simulating API response
  }
}
