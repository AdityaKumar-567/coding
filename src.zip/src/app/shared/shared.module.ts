import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { PublicHeaderComponent } from './public-header/public-header.component';

@NgModule({
  declarations: [PublicHeaderComponent], // Declare the header component
  imports: [CommonModule, RouterModule],
  exports: [PublicHeaderComponent, RouterModule], // Export so other modules can use it
})
export class SharedModule {}
